import "./style/style.css";
import "./components/component.js";
import main from "./script/main.js";

main();