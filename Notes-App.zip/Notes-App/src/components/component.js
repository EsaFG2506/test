import './header-bar.js';
import './footer-bar.js';
import './note-form.js';